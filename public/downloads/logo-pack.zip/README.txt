EXPOSURE by 29029 — Logo Pack
Placeholder. Replace with final SVG/PNG wordmark + triangle exports.
