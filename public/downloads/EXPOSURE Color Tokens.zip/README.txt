EXPOSURE Brand Colors

Four colors. Use Off-Black and Off-White as base. Use Red for emphasis only.
Use Gold sparingly as an accent. Hex values are the source of truth.
